/** Automatically generated file. DO NOT MODIFY */
package sensor.data;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}