package sensor.data;

import java.util.List;
import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class AndroidSensorDataActivity extends Activity {
	private SensorManager mSensorManager;
    /** Called when the activity is first created. */
    @Override
    
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        //create text view control
        TextView thisView = new TextView(this);
        
        //get list of available sensors
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> deviceSensors = mSensorManager.getSensorList(Sensor.TYPE_ALL);
        
        //populate text view with list
        String eol = System.getProperty("line.separator");
        for (Sensor sensor : deviceSensors) {
        	thisView.append(sensor.getName() + eol);
    	}
        setContentView(thisView);
    }
}